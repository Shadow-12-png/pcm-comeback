# PCM Comeback v2

A mobile-first PWA dashboard for the Class 11 PCM comeback plan.

### Added
- App-style dashboard
- Today's Mission
- One-tap complete-today
- Overall progress
- Physics / Chemistry / Maths dashboard
- Streak counter
- Full plan tab
- Settings/reset tab
- Bottom navigation
- Install prompt + PWA manifest
- Offline service worker
- Local progress saving

### Install
Host the files on an HTTPS site, open it in Chrome on Android, then choose **Add to home screen** or **Install app**.
